// register.php (Employee Registration)
<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $join_date = $_POST['join_date'];

    $stmt = $connection->prepare("INSERT INTO employees (name, email, password, role, join_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $password, $role, $join_date);
    if ($stmt->execute()) {
        echo "Employee registered successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
