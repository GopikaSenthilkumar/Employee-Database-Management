// dashboard.php (Dashboard Page)
<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="navbar">
        <h2>Dashboard</h2>
        <a href="logout.php">Logout</a>
    </div>
    <div class="content">
        <h1>Welcome, <?php echo $_SESSION['user_name']; ?>!</h1>
        <p>Your role: <?php echo $_SESSION['role']; ?></p>
    </div>
</body>
</html>