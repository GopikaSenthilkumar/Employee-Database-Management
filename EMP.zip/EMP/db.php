// db.php (Database Connection)
<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'employee_management';
$connection = new mysqli($host, $user, $pass, $db);
if ($connection->connect_error) {
    die("Database connection failed: " . $connection->connect_error);
}
?>