// index.php (Homepage with Navigation)
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Employee Management System</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="navbar">
        <h2>Employee Management System</h2>
        <a href="index.php">Home</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="content">
        <h1>Welcome to Employee Management System</h1>
    </div>
</body>
</html>